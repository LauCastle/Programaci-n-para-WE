const app_mypost ={
    url: "app/app.php",

    mp: $("#my-posts"),

    getMyPosts : function(uid){
        let html = `<tr><ts colspan="3">Aun no tiene publicaciones </td></tr>`;
        this.mp.html("");
        fetch(this.url + "?_mp&uid=" + uid)
        .then(resp => resp.json())
        .then(mpresp => {
                if( mpresp.length > 0){
                    html= "";
                    for( let post of mpresp){
                        html += ","

                    }
                }
        }) 
    },
}