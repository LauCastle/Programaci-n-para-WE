<?php

header("Location: ./resources/views/inicio.php");