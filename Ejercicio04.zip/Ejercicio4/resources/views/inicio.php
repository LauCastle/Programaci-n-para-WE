<?php 
    include "./layouts/main.php";

    head();
?>
<div class="row mx-auto" style="90%">
    <div class="col-8">
        <div id="content" class="content">
            <!-- Publicaciones -->
        </div>
    </div>
    <div class="col-4">
        <div id="authors" class="list-group">
            <!-- Autores -->

        </div>
    </div>
</div>
<?php
    
    scripts();

    foot();